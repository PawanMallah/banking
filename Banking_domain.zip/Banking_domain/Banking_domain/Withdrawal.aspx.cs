﻿using Banking_domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banking_domain
{
    public partial class withdrawal1 : System.Web.UI.Page
    {
        BankingEntities bankingEntities = new BankingEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Withdrawal_Click(object sender, EventArgs e)
        {
            try
            {
                int userId = int.Parse(Session["UserId"].ToString());
                
                var Bal = bankingEntities.balances.Where(x => x.userId == userId).ToList();
                if (Bal != null && Bal.Any())
                {
                    if(Bal.FirstOrDefault().balance1 > int.Parse(Amount.Text))
                    {
                        bankingEntities.withdrawals.Add(
                    new withdrawal()
                    {
                        dateTime = DateTime.Now,
                        withdrawalAmount = int.Parse(Amount.Text),
                        userId = userId

                    });
                        Bal.FirstOrDefault().balance1 -= int.Parse(Amount.Text);
                        msg.Text = Amount.Text + " withdraw Succesfully";
                        
                    }
                    else
                    {
                        msg.Text = "Amount is Less then " + Amount.Text;
                    }
                    msg.Visible = true;
                }

                bankingEntities.SaveChanges();
               
            }
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}