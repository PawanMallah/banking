﻿using Banking_domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banking_domain
{
    public partial class Deposite1 : System.Web.UI.Page
    {
        BankingEntities bankingEntities = new BankingEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Deposite_Click(object sender, EventArgs e)
        {
            try
            {
                int userId = int.Parse(Session["UserId"].ToString());
                bankingEntities.Deposites.Add(
                    new Deposite()
                    {
                        dateTime = DateTime.Now,
                        DepositeAmount = int.Parse(Amount.Text),
                        userId = userId

                    });
                var Bal = bankingEntities.balances.Where(x => x.userId == userId).ToList();
                if(Bal != null && Bal.Any())
                {
                    Bal.FirstOrDefault().balance1 += int.Parse(Amount.Text);
                }
                else
                {
                    balance balance = new balance();
                    balance.balance1 = int.Parse(Amount.Text);
                    balance.userId = userId;
                    bankingEntities.balances.Add(balance);
                }

                bankingEntities.SaveChanges();
                msg.Text = Amount.Text + " Deposite Succesfully";
                msg.Visible = true;
            }catch(Exception ex)
            {
                Response.Redirect("Login.aspx");
            }
        }
    }
}