﻿using Banking_domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banking_domain
{
    public partial class ViewBalance : System.Web.UI.Page
    {
        BankingEntities bankingEntities = new BankingEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        // The return type can be changed to IEnumerable, however to support
        // paging and sorting, the following parameters must be added:
        //     int maximumRows
        //     int startRowIndex
        //     out int totalRowCount
        //     string sortByExpression
        public List<Banking_domain.balance> BalanceGrid_GetData()
        {
            List<Banking_domain.balance> result = null;
            try
            {
               
                if (Session["isAdmin"] != null && Session["isAdmin"].ToString() == "1")
                {
                    result = bankingEntities.balances.ToList();
                }
                else
                {
                    int userId = int.Parse(Session["UserId"].ToString());
                    result = bankingEntities.balances.Where(x => x.userId == userId).ToList();
                }
            }catch(Exception e)
            {
                Response.Redirect("Login.aspx");
            }
            return result;
            //return null;
        }
    }
}