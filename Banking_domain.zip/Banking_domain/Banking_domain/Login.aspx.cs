﻿using Banking_domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banking_domain
{
    public partial class Login : System.Web.UI.Page
    {
        BankingEntities bankingEntities = new BankingEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Login_Click(object sender, EventArgs e)
        {
            if(Username.Text == "" || Password.Text == "")
            {
                msg.Text = "Please Enter Username and password";
                msg.Visible = true;
            }
            var username = Username.Text;
            var password = Password.Text;

            var data = bankingEntities.Users.Where(x=>x.username == username && x.password == password).ToList();
            if(data != null && data.Any())
            {
                Session["UserId"] = data.FirstOrDefault().id;
                Session["isAdmin"] = data.FirstOrDefault().isAdmin;
                if (data.FirstOrDefault().isAdmin == 1)
                {
                    Response.Redirect("AdminHome.aspx");
                }
                else
                {
                    Response.Redirect("Home.aspx");
                }
            }else
            {
                msg.Text = "Wrong Username and password";
                msg.Visible = true;
            }
        }
    }
}