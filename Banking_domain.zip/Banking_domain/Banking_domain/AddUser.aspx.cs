﻿using Banking_domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Banking_domain
{
    public partial class AddUser : System.Web.UI.Page
    {
        BankingEntities bankingEntities = new BankingEntities();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Register_Click(object sender, EventArgs e)
        {
            if (password.Text.Equals(RePassword.Text))
            {
                User user = new User();
                user.username = username.Text;
                user.password = password.Text;
                bankingEntities.Users.Add(user);
                bankingEntities.SaveChanges();
                msg.Text = "User Added Succesfully";
                msg.Visible = true;
            }
            else
            {
                msg.Text = "Please Enter same password";
                msg.Visible = true;
            }
        }
    }
}